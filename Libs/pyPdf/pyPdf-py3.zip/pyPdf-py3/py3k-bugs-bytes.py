class Test(bytes):
    pass


