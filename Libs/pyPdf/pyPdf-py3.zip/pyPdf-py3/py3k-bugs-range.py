class Test(int):
    pass

for x in range(Test(5)):
    print(x)
